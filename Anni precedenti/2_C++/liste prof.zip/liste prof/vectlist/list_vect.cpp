#include "listdl.hpp"
#include <iostream>

constexpr int capacity = 15;


struct List_dl::Impl{
	int* vect;  //vettore allocato in memoria dinamica
	int empty;  //Indice del blocco prima cella libera, -1 se lista piena
	int head;   //Indice del blocco prima cella, -1 se lista vuota
	int trash;  //Variabile di comodo per l'at
};

List_dl::List_dl() {
	pimpl = new Impl;
	pimpl->vect = new int[capacity];

	pimpl->head = -1;
	pimpl->empty = 0;

	for (int i=0; i<capacity/3; i++) {
		if (i!=capacity/3-1) 
			pimpl->vect[i*3+2] = (i+1)*3;
		else
			pimpl->vect[i*3+2] = -1;
		if (i!=0)
			pimpl->vect[i*3] = (i-1)*3;
		else
			pimpl->vect[i*3] = -1;
	}
}

List_dl::~List_dl() {
	delete[] pimpl->vect;
	delete pimpl;
}

List_dl::List_dl(const List_dl& copy) {
      pimpl = new Impl;
      pimpl->vect = new int[capacity];

      for (int i=0; i<capacity; i++)
           pimpl->vect[i] = copy.pimpl->vect[i];  

      pimpl->head = copy.pimpl->head;
      pimpl->empty = copy.pimpl->empty;
}    



void List_dl::prepend(int elem) {
	if (pimpl->empty!=-1) {//Ho almeno un blocco libero
		int nuovo = pimpl->empty;
		pimpl->empty = pimpl->vect[pimpl->empty+2];
		if (pimpl->empty!=-1) 
			pimpl->vect[pimpl->empty] = -1;


		pimpl->vect[nuovo] = -1; //non serve perche' tolgo dalla testa
		pimpl->vect[nuovo+1] = elem; 
		pimpl->vect[nuovo+2] = pimpl->head;
		if (pimpl->head!=-1)
			pimpl->vect[pimpl->head] = nuovo;
		pimpl->head = nuovo;
	}
}


void List_dl::append(int elem) {
	if (pimpl->empty!=-1) {
		if (pimpl->head==-1) //Lista vuota
			prepend(elem);
		else {
			int pc = pimpl->head;
			while (pimpl->vect[pc+2]!=-1) //Ciclo che mi porta all'ultima cella della lista
				pc = pimpl->vect[pc+2];

			//Estrazione di un blocco dalla lista dei blocchi vuoti
			int nuovo = pimpl->empty;
			pimpl->empty = pimpl->vect[pimpl->empty+2];
			if (pimpl->empty!=-1) 
				pimpl->vect[pimpl->empty] = -1;

			pimpl->vect[nuovo] = pc;
			pimpl->vect[nuovo+1] = elem;
			pimpl->vect[nuovo+2] = -1;

			pimpl->vect[pc+2] = nuovo;
		}
	}
}

void List_dl::print_raw() {
	std::cout<<"Array raw"<<std::endl;
	for (int i=0; i<capacity; i++) 
		std::cout<<pimpl->vect[i] << " ";
	std::cout<<std::endl;

	std::cout<<"Lista: "<<std::endl;
	int pc = pimpl->head;
	while (pc!=-1) {
		std::cout<<pimpl->vect[pc+1]<<" "; //stampo l'info
		pc = pimpl->vect[pc+2]; //passo al next
	}
	std::cout<<std::endl;
}

int& List_dl::at(int pos) {
	int pc = pimpl->head;

	while (pos>0 && pc!=-1) {
		pc = pimpl->vect[pc+2];
		pos--;
	}

	if (pc!=-1) //pos esiste nella lista
		return pimpl->vect[pc+1];
	else
		return pimpl->trash;

}

const int& List_dl::at(int pos) const {
	int pc = pimpl->head;

	while (pos>0 && pc!=-1) {
		pc = pimpl->vect[pc+2];
		pos--;
	}

	if (pc!=-1) //pos esiste nella lista
		return pimpl->vect[pc+1];
	else
		return pimpl->trash;

}
