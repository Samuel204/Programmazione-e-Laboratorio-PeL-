#include "listdl.hpp"
#include<iostream>

int main() {
	List_dl mylist;
	std::cout<<"Lista vuota"<<std::endl;
	mylist.print_raw();
	
	mylist.prepend(100);
	mylist.prepend(90);
	mylist.append(91);

	std::cout<<"Lista con due elementi"<<std::endl;

	mylist.print_raw();

	return 0;
}
