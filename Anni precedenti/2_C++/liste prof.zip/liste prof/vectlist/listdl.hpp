#include<string>


class List_dl{
	public:
		List_dl();  //Costruttore di default
		List_dl(const List_dl& copy);  //Copy constructor
		~List_dl();

		void prepend(int elem);
		void print_raw();
		void append(int elem);
		//std::string to_string() const;
		//int size() const;
		//int erase(int elem); //elimina tutte le occorrenze di elem e restituisce quante ne ha eliminate

		int& at(int pos);
		const int& at(int pos) const;
	private:
		struct Impl;
		Impl* pimpl;
};

