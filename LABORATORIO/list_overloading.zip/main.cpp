#include<string>
#include "list_overloading.hpp"
#include<iostream>

using namespace std;

bool List_int::empty()const{
    return  !l;
}


//accesses private members of List_int, so we need to make if friend(from inside List_int)
//note: left-hand side is not a List_int, so we cannot define this operator
//as a member function of List_int
std::ostream & operator<<(std::ostream& out, const List_int& L){

    List_int::Cella* ptr = L.l;

    if(L.empty())
        return out;

    while(ptr->next){
        out << ptr->info << "->";
        ptr = ptr->next;
    }

    out << ptr->info;
    return out;
}

//l3 = l1 + l2
List_int List_int::operator+(const List_int& rhs)const{
    List_int result(*this);
    Cella* ptr = rhs.l;

    result += rhs;

    return result;
}

//Does not access private members of List_int, so no need to make it friend
//left-hand side is a List_int, so we may as well define this operator as
//a member function of List_int (as we did with the other operators).
List_int operator+(const List_int& lhs, const List_int& rhs){

    List_int result = lhs;

    result += rhs;

    return result;

}



//List_int
//l[5] = 6;
int& List_int::operator[](int i) const {
    Cella* ptr = l;
    while(i-- > 0){
        ptr = ptr->next;
    }
    return ptr->info;
}

//l1+=l2
List_int& List_int::operator+=(List_int& rhs){

    if(this == &rhs){
        //we decide to empty l1

        while(!empty())
            remove_first();

        return *this;
    }
    while(!rhs.empty()){
        append(rhs.first());
        rhs.remove_first();
    }
    return *this;
}


//l1 = l2
List_int& List_int::operator=(const List_int &rhs) {
    if(this == &rhs) return *this; //l'oggetto è lo stesso

    delete this;

    Cella* ptr = rhs.l;

    while(ptr){
        append(ptr->info);
        ptr = ptr->next;
    }
    return *this;
}

/*L1 += L1 does not compile if l1 is const, however one could
*  call l1 += l1_c, where l1_c is a const reference to l1!
*  in this case we do not have a compilation error so we
*  need to consider the case this == &rhs also here
*/
//l1 += l1
List_int& List_int::operator+=(const List_int& rhs){

    if(this == &rhs){
        Cella* end = last;
        Cella* ptr = l;

        append(ptr->info);

        while(ptr) {
            append(ptr->info);
            ptr = ptr->next;
        }
        return *this;
    }
    Cella* ptr = rhs.l;

    while(ptr){
        append(ptr->info);
        ptr = ptr->next;
    }
    return *this;

}

//mettiamo list_int:: perche andiamo a scrivere la funzione fuori dalla classe
bool List_int::operator==(const List_int &rhs) const {

    // *this;
    // rhs;

    Cella* ptr1 = l;
    Cella* ptr2 = rhs.l;

    while(ptr1 && ptr2){
        if(ptr1->info != ptr2->info) {
            return false;
        }
        ptr1 = ptr1->next;
        ptr2 = ptr2->next;
    }
    return !(ptr1 || ptr2);

}

List_int::List_int() :l{nullptr}, last{nullptr}  {
} //Crea la lista vuota

List_int::List_int(int el) {
    l = new Cella;
    l->info=el;
    l->next=nullptr;
    last=l;
}

List_int::List_int(const List_int& source) {

    l = nullptr;
    last = nullptr;
    Cella* pc = source.l;

    while (pc) {
        append(pc->info);
        pc = pc->next;
    }
}

void List_int::prepend(int el) {
    Cella* nuova = new Cella;
    nuova->info = el;
    nuova->next = l;
    l = nuova;
    if (last==nullptr)
        last=nuova;
}

void List_int::append(int el) {
    Cella* nuova = new Cella;
    nuova->info = el;
    nuova->next=nullptr;

    if (l==nullptr) {
        l=nuova;
        last=nuova;
    }
    else {
        last->next = nuova;
        last = nuova;
    }
}

std::string List_int::convert_to_string() const{
    std::string res{};
    Cella* pc{l};

    while (pc) {
        res = res + std::to_string(pc->info) + " ";
        pc = pc->next;
    }
    return res;
}


List_int::~List_int() {
    Cella* pc;
    while(l) {
        pc = l;
        l=l->next;
        delete pc;
    }
}


int& List_int::first() {
    return l->info;
}


const int& List_int::first() const {
    return l->info;
}

void List_int::remove_first() {
    if (l) {
        Cella* pc = l;
        l=l->next;
        delete pc;
        if (l==nullptr)
            last = nullptr;
    }
}


void read_list(List_int& l) {
    int elem, member;
    std::cin>>elem;

    while (elem>0) {
        std::cin >> member;
        l.append(member);
        elem--;
    }
}


int main() {
    List_int l1;
    List_int l2_nc;

    read_list(l1);
    read_list(l2_nc);

    const List_int l2 = l2_nc;

    cout << "l1: " <<l1.convert_to_string() << endl;
    cout << "l2: " <<l2.convert_to_string() << endl;

    l1 += l2;

    cout << "l1: " <<l1.convert_to_string() << endl;
    cout << "l2: " <<l2.convert_to_string() << endl;

    if(l1 == l2){
        cout << "liste uguale" << endl;
    }else{
        cout << "liste diverse" << endl;
    }

}