#ifndef LEZIONE_LAB_LIST_OVERLOADING_H
#define LEZIONE_LAB_LIST_OVERLOADING_H

#endif //LEZIONE_LAB_LIST_OVERLOADING_H

class List_int{
public:
    List_int();
    List_int(int el);
    List_int(const List_int& source);

    void prepend(int el);
    void append(int el);

    std::string convert_to_string() const;
    int& first();
    const int& first() const;

    void remove_first();

    ~List_int();

    //overloading
    //does not modify arguments return booean
    bool operator==(const List_int& rhs)const;


    // l1 = l2
    // overwrites the content of l1 with the content of l2
    // does not modify l2
    List_int& operator=(const List_int& rhs);


    //l1 = l2
    //overwrite the content of l1 with the content of l2
    //does not modify l2
    List_int& operator+=(const List_int& rhs);

    //l3 = l1 + l2
    //inserts into l3 the concatenation of l1 and l2
    //does not modify l1 and l2
    List_int operator+(const List_int& rhs)const;

    //l1 += (l2 += (l2 += l4))
    //appends l2 at the end of l1, empies l2
    List_int& operator+=(List_int& rhs);

    /*// l1 += l2
    // appends l2 at the end of l1, does not modify l2
    List_int& operator+=(const List_int& rhs);*/

    //return a reference to the info of the i-th cella
    //l1[4] = 9
    int& operator[](int i)const;

    bool List_int::empty()const;

private:

    //we need to make this function friiend because it will access private members
    //this is not a member function! no difference if you it in private or public

    friend std::ostream& operator<<(std::ostream&, const List_int&);

    struct Cella{
        int info;
        Cella* next;
    };

    Cella* l;     //Punt. prima cella della lista
    Cella* last;  //Punt. ultima cella della lista
    //Lista vuota codificata con l==last==nullptr
};
